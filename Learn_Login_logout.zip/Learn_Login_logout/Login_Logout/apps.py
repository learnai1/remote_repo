from django.apps import AppConfig


class LoginLogoutConfig(AppConfig):
    name = 'Login_Logout'
