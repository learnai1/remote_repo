from django.contrib import admin
from django.urls import path
from Login_Logout import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.register_view,name='register'),
    path('login/',views.Login_view,name='login'),
    path('home/',views.home,name='home')

]